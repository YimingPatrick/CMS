package com.java456;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CallManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(CallManagementSystemApplication.class, args);
	}

}
