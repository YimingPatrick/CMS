package com.java456.entity.cms;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.java456.entity.base.CustomDateTimeSerializer;


@Entity
@Table(name = "t_a_client")
public class Client {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	@NotNull(message="账号不能为空！")
	@Column(length=30)
	private  String name;//账号
	@NotNull(message="密码不能为空！")
	@Column(length=30)
	private  String pwd;//密码
	@NotNull(message="密码不能为空！")
	@Column(length=30)
	private  String trueName;// 真实姓名
	@NotNull(message="性别不能为空！")
	@Column(length=11)
	private  Integer sex  ;//性别   1男2女
	
	
	@NotNull(message="年龄不能为空！")
	@Column(length=11)
	private  Integer age  ;//年龄
	@NotNull(message="地址不能为空！")
	@Column(length=11)
	private  String address  ;// 地址
	@NotNull(message="电话不能为空！")
	@Column(length=11)
	private  String phone  ;// 电话
	@Temporal(TemporalType.TIMESTAMP) 
	private Date createDateTime;//注册时间
	@Column(length=11)
	private  Integer state  ;// 0暂停使用   1正常  2封号
	
	
	public Integer getState() {
		return state;
	}
	public void setState(Integer state) {
		this.state = state;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getTrueName() {
		return trueName;
	}
	public void setTrueName(String trueName) {
		this.trueName = trueName;
	}
	public Integer getSex() {
		return sex;
	}
	public void setSex(Integer sex) {
		this.sex = sex;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	@JsonSerialize(using = CustomDateTimeSerializer.class)
	public Date getCreateDateTime() {
		return createDateTime;
	}
	public void setCreateDateTime(Date createDateTime) {
		this.createDateTime = createDateTime;
	}
	
	
	
	
}
