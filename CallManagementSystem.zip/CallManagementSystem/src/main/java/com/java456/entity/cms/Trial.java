package com.java456.entity.cms;


import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.java456.entity.base.CustomDateTimeSerializer;


@Entity
@Table(name = "t_trial")
public class Trial {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	@ManyToOne
	@JoinColumn(name="applicantId")
	private Client applicant; //申请人
	@ManyToOne
	@JoinColumn(name="callRecordId")
	private CallRecord callRecord; //拨打记录id
	@Column(length=11)
	private  Integer state  ;//状态  0处理中  1已处理   
	@Temporal(TemporalType.TIMESTAMP) 
	private Date createDateTime;//审诉时间
	@Column(length=30)
	private  String content;// 早诉内容
	@Column(length=30)
	private  String remark;//备注处理结果
	
	
	
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Client getApplicant() {
		return applicant;
	}
	public void setApplicant(Client applicant) {
		this.applicant = applicant;
	}
	public CallRecord getCallRecord() {
		return callRecord;
	}
	public void setCallRecord(CallRecord callRecord) {
		this.callRecord = callRecord;
	}
	public Integer getState() {
		return state;
	}
	public void setState(Integer state) {
		this.state = state;
	}
	
	@JsonSerialize(using = CustomDateTimeSerializer.class)
	public Date getCreateDateTime() {
		return createDateTime;
	}
	public void setCreateDateTime(Date createDateTime) {
		this.createDateTime = createDateTime;
	}
	
	
	
	
	
}
