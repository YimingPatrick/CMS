package com.java456.entity.cms;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.java456.entity.base.CustomDateTimeSerializer;
import com.java456.entity.base.Role;

@Entity
@Table(name = "t_contacts")
public class Contacts {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	@NotNull(message="姓名不能为空！")
	@Column(length=11)
	private  String trueName  ;//姓名
	@NotNull(message="地址不能为空！")
	@Column(length=11)
	private  String address  ;//地址
	@NotNull(message="电话不能为空！")
	@Column(length=11)
	private  String phone  ;// 电话
	@Temporal(TemporalType.TIMESTAMP) 
	private Date createDateTime;//创建时间
	@ManyToOne
	@JoinColumn(name="createClientId")
	private Client createClient; // 创建人
	
	
	
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getTrueName() {
		return trueName;
	}
	public void setTrueName(String trueName) {
		this.trueName = trueName;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	@JsonSerialize(using = CustomDateTimeSerializer.class)
	public Date getCreateDateTime() {
		return createDateTime;
	}
	public void setCreateDateTime(Date createDateTime) {
		this.createDateTime = createDateTime;
	}
	public Client getCreateClient() {
		return createClient;
	}
	public void setCreateClient(Client createClient) {
		this.createClient = createClient;
	}
	
	
	
	
}
