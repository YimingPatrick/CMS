package com.java456.entity.cms;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.java456.entity.base.CustomDateTimeSerializer;

@Entity
@Table(name = "t_call_record")
public class CallRecord {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;
	@ManyToOne
	@JoinColumn(name="initiatorId")
	private Client initiator; //发起人 拨打人
	@ManyToOne
	@JoinColumn(name="receiverId")
	private Client receiver; //接受者
	@Temporal(TemporalType.TIMESTAMP) 
	private Date createDateTime;//呼出 呼入 时间
	
	@Column(length=30)
	private  String phone1;//  发起电话 
	@Column(length=30)
	private  String phone2;//接受电话 
	
	
	
	
	public String getPhone1() {
		return phone1;
	}
	public void setPhone1(String phone1) {
		this.phone1 = phone1;
	}
	public String getPhone2() {
		return phone2;
	}
	public void setPhone2(String phone2) {
		this.phone2 = phone2;
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Client getInitiator() {
		return initiator;
	}
	public void setInitiator(Client initiator) {
		this.initiator = initiator;
	}
	public Client getReceiver() {
		return receiver;
	}
	public void setReceiver(Client receiver) {
		this.receiver = receiver;
	}
	@JsonSerialize(using = CustomDateTimeSerializer.class)
	public Date getCreateDateTime() {
		return createDateTime;
	}
	public void setCreateDateTime(Date createDateTime) {
		this.createDateTime = createDateTime;
	}
	
	
	
	
}
