package com.java456.service.cms;

import java.util.List;
import java.util.Map;
import com.java456.entity.cms.Notice;


public interface NoticeService {
	
	public void update(Notice notice  );
	
}
