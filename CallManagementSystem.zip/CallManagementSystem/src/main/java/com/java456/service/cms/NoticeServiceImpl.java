package com.java456.service.cms;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import org.springframework.stereotype.Service;
import com.java456.dao.cms.NoticeDao;
import com.java456.entity.cms.Notice;
import com.java456.entity.cms.Trial;


@Service("noticeService")
public class NoticeServiceImpl implements NoticeService {
	
	@Resource
	private NoticeDao noticeDao;
	/**
	 * @param curr      当前更新的数据
	 * @param origin   源数据  以前的数据
	 * @return  curr
	 */
	public Notice repalce(Notice curr,Notice origin){
		if(curr.getTitle()   ==null){
			curr.setTitle(origin.getTitle());
		}
		if(curr.getContent()  ==null){
			curr.setContent(origin.getContent());
		}
		if(curr.getCreateDateTime()  ==null){
			curr.setCreateDateTime(origin.getCreateDateTime());
		}
		return curr;
	}
	
	@Override
	public void update(Notice notice) {
		Notice origin = noticeDao.findId(notice.getId());
		notice = repalce(notice, origin);
		noticeDao.save(notice);
	}
	
}
