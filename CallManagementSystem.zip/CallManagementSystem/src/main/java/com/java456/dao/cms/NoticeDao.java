package com.java456.dao.cms;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import com.java456.entity.cms.Notice;


public interface NoticeDao extends JpaRepository<Notice,Integer>,JpaSpecificationExecutor<Notice> {

	@Query(value="select * from t_notice where id = ?1",nativeQuery = true)
	public Notice findId(Integer id);
	
}
