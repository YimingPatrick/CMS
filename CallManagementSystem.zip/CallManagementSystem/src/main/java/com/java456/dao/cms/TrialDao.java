package com.java456.dao.cms;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import com.java456.entity.cms.Trial;

public interface TrialDao  extends JpaRepository<Trial,Integer>,JpaSpecificationExecutor<Trial> {

	@Query(value="select * from t_trial where id = ?1",nativeQuery = true)
	public Trial findId(Integer id);
	
	
}
