package com.java456.dao.cms;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;

import com.java456.entity.base.User;
import com.java456.entity.cms.Contacts;

public interface ContactsDao  extends JpaRepository<Contacts,Integer>,JpaSpecificationExecutor<Contacts> {

	@Query(value="select * from t_contacts where id = ?1",nativeQuery = true)
	public Contacts findId(Integer id);
}
