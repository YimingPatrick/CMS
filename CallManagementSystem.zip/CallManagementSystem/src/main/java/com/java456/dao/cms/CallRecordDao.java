package com.java456.dao.cms;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import com.java456.entity.cms.CallRecord;


public interface CallRecordDao extends JpaRepository< CallRecord,Integer>,JpaSpecificationExecutor< CallRecord> {

	@Query(value="select * from t_call_record where id = ?1",nativeQuery = true)
	public CallRecord findId(Integer id);
	
	
}
