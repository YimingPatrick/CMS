package com.java456.controller;

import java.util.Date;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authc.IncorrectCredentialsException;
import org.apache.shiro.authc.UnknownAccountException;
import org.apache.shiro.authc.UsernamePasswordToken;
import org.apache.shiro.subject.Subject;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import com.java456.dao.cms.ClientDao;
import com.java456.entity.base.User;
import com.java456.entity.cms.Client;
import com.java456.util.CryptographyUtil;

import net.sf.json.JSONObject;

@Controller
@RequestMapping("/client")
public class ClientController {
	
	@Resource
	private ClientDao clientDao;
	
	/**
	 *   /client/add
	 */
	@ResponseBody
	@RequestMapping("/add")
	public JSONObject add(@Valid Client client  , BindingResult bindingResult, HttpServletResponse response,
			HttpServletRequest request) throws Exception {
		JSONObject result = new JSONObject();
		if (bindingResult.hasErrors()) {
			result.put("success", false);
			result.put("msg", bindingResult.getFieldError().getDefaultMessage());
			return result;
		} else {
			//判断 name有没有重复
			Client tempClient = clientDao.findByName(client.getName());
			//判断  phone 不能重复
			Client phonClient = clientDao.findByPhone(client.getPhone());
			
			if(tempClient==null&&phonClient==null) {
				client.setCreateDateTime(new Date());
				client.setState(1);
				clientDao.save(client);
				result.put("success", true);
				result.put("msg", "Added successfully");
				return result;
			}else {
				result.put("success", false);
				result.put("msg", "Sorry，Username already exists");
				return result;
			}
		}
	}
	
	/**
	 * @登录验证的url
	 * @param name
	 * @param pwd
	 */
	@ResponseBody
	@RequestMapping("/check")
	public JSONObject check(String name,String pwd,HttpSession session)throws Exception {
		JSONObject result = new JSONObject();
		
		Client client   = clientDao.findByName(name);
		
		if(client==null) {
			result.put("success", false);
			result.put("msg","The user does not exist");
			return result;
		}
		if(pwd.equals(client.getPwd())) {
			//判断 帐号有没有封
			if(client.getState()==2) {
				result.put("success", false);
				result.put("msg","The account was blocked");
				return result;
			}
			//判断 帐号有没有封
			
			session.setAttribute("client", client);
			result.put("success", true);
			result.put("msg","login in successfully");
			return result;
		}else {
			result.put("success", false);
			result.put("msg","wrong password");
			return result;
		}
	}
	
	/**
	 * !注销
	 * /client/logout
	 * @throws Exception
	 */
	@RequestMapping("/logout")
	public String logout(HttpSession session)throws Exception{
		session.setAttribute("client", null); 
		return "redirect:/client/login";
	}
	
	/**
	 *  #/client/checkPhone
	 * @拨打电话  验证电话 是否存在
	 * @param name
	 * @param pwd
	 */
	@ResponseBody
	@RequestMapping("/checkPhone")
	public JSONObject checkPhone(String phone,HttpSession session)throws Exception {
		JSONObject result = new JSONObject();
		Client client   = clientDao.findByPhone(phone);
		
		//不能是自己的号码
		Client s_client = (Client) session.getAttribute("client");
		if(phone.equals(s_client.getPhone())) {
			result.put("success", false);
			result.put("msg", "Can't call your number");
			return result;
		}
		//不能是自己的号码
		
		if(client==null) {
			result.put("success", false);
			result.put("msg", "The telephone does not exist!");
			return result;
		}else {
			result.put("success", true);
			return result;
		}
	}
	
	
}
