package com.java456.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.java456.dao.base.UserDao;
import com.java456.dao.cms.NoticeDao;
import com.java456.entity.cms.Notice;


@Controller
@RequestMapping("/notice")
public class NoticeController {
	
	
	@Resource
	private NoticeDao  noticeDao;
	
	/**
	 *  /notice/1
	 * @return springmvc会自动把这个id提出来 /a/shop/1   会自动 提出1当id
	 * @throws Exception
	 */
	@RequestMapping("/{id}")
	public ModelAndView view(@PathVariable("id") Integer id,HttpServletRequest request) throws Exception {
		ModelAndView mav = new ModelAndView();
		Notice notice      = noticeDao.findId(id);
		mav.addObject("notice", notice);
		mav.setViewName("/pc/notice/view");
		return mav;
	}
}
