package com.java456.controller.cms.admin;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.java456.dao.cms.NoticeDao;
import com.java456.entity.cms.Client;
import com.java456.entity.cms.Notice;
import com.java456.entity.cms.Trial;
import com.java456.service.cms.NoticeService;
import com.java456.util.StringUtil;

import net.sf.json.JSONObject;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;


@Controller
@RequestMapping("/admin/notice")
public class Admin_Notice_Controller {
	
	@Resource
	private NoticeDao noticeDao;
	@Resource
	private NoticeService  noticeService;
	
	/**
	 * /admin/notice/add
	 */
	@ResponseBody
	@RequestMapping("/add")
	public JSONObject add(@Valid Notice notice,BindingResult bindingResult, HttpSession session) throws Exception {
		JSONObject result = new JSONObject();
		if(bindingResult.hasErrors()){
			result.put("success", false);
			result.put("msg", bindingResult.getFieldError().getDefaultMessage());
			return result;
		}else{
			notice.setCreateDateTime(new Date());
			noticeDao.save(notice);
			result.put("success", true);
			result.put("msg", "Complainted successfully");
			return result;
		}
	}
	
	/**
	 * /admin/notice/update
	 */
	@ResponseBody
	@RequestMapping("/update")
	public JSONObject update(@Valid  Notice notice ,BindingResult bindingResult)throws Exception {
		JSONObject result = new JSONObject();
		if(bindingResult.hasErrors()){  
			result.put("success", false);
			result.put("msg", bindingResult.getFieldError().getDefaultMessage());
			return result;
		}else{
			noticeService.update(notice);
			result.put("success", true);
			result.put("msg", "modified successfully");
			return result;
		}
	}
	
	
	/**
	 * /admin/trial/list    applicantId=1
	 * @param page    默认1
	 * @param limit   数据多少  
	 */
	@ResponseBody
	@RequestMapping("/list")
	public Map<String, Object> list(@RequestParam(value = "page", required = false) Integer page,
			@RequestParam(value = "limit", required = false) Integer limit) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		

		Pageable pageable=new PageRequest(0, 100, Sort.Direction.DESC,"id");
		Page<Notice> list = noticeDao.findAll(pageable);
		
		List<Notice> noticeList =list.getContent();//拿到list集合
		Long total = noticeDao.count();
		
		map.clear();
		map.put("data", noticeList);
		map.put("count", total);
		map.put("code", 0);
		map.put("msg", "");
		return map;
	}
	
	
	/**
	 * /admin/notice/delete
	 */
	@ResponseBody
	@RequestMapping("/delete")
	public JSONObject delete(@RequestParam(value = "ids", required = false) String ids, HttpServletResponse response)
			throws Exception {
		String[] idsStr = ids.split(",");
		JSONObject result = new JSONObject();
		for (int i = 0; i < idsStr.length; i++) {
			try {
				noticeDao.deleteById(Integer.parseInt(idsStr[i]));
			} catch (Exception e) {
				result.put("success", false);
				return result;
			}
		}
		result.put("success", true);
		return result;
	}
	
	
	
	
}
