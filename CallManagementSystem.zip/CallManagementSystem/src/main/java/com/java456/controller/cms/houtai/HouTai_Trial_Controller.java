package com.java456.controller.cms.houtai;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.java456.dao.cms.CallRecordDao;
import com.java456.dao.cms.TrialDao;
import com.java456.entity.cms.CallRecord;
import com.java456.entity.cms.Contacts;
import com.java456.entity.cms.Trial;
import com.java456.service.cms.CallRecordService;

@Controller
@RequestMapping("/houtai/trial")
public class HouTai_Trial_Controller {
	
	@Resource
	private CallRecordDao callRecordDao  ;
	@Resource
	private TrialDao trialDao  ;
	
	/**
	 * /houtai/trial/add?callRecordId=12
	 */
	@RequestMapping("/add")
	public ModelAndView add(@RequestParam(value = "callRecordId", required = false) Integer callRecordId) throws Exception {
		ModelAndView mav = new ModelAndView();
		CallRecord callRecord =    callRecordDao.findId(callRecordId);
		mav.addObject("callRecord", callRecord);
		mav.setViewName("/pc/trial/add");
		return mav;
	}
	
	/**
	 * /houtai/trial/edit?id=1
	 */
	@RequestMapping("/edit")
	public ModelAndView edit(@RequestParam(value = "id", required = false) Integer id) throws Exception {
		ModelAndView mav = new ModelAndView();
		Trial trial = trialDao.findId(id);
		mav.addObject("trial", trial);
		mav.addObject("btn_text", "修改");
		mav.addObject("save_url", "/admin/trial/update?id=" + id);
		mav.setViewName("/admin/page/trial/edit");
		return mav;
	}
	
	
	
	/**
	 * #我的申诉
	 * /houtai/trial/my/manage
	 */
	@RequestMapping("/my/manage")
	public ModelAndView my_manage() throws Exception {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("/pc/trial/my_manage");
		return mav;
	}
	
	/**
	 * # 申诉管理
	 * /houtai/trial/manage
	 */
	@RequestMapping("/manage")
	public ModelAndView manage() throws Exception {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("/admin/page/trial/manage");
		return mav;
	}
	
	
}
