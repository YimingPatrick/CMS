package com.java456.controller.cms.houtai;

import javax.annotation.Resource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.java456.dao.cms.CallRecordDao;
import com.java456.dao.cms.ContactsDao;
import com.java456.entity.base.Role;
import com.java456.entity.cms.CallRecord;
import com.java456.entity.cms.Contacts;

@Controller
@RequestMapping("/houtai/contacts")
public class HouTai_Contacts_Controller {
	
	@Resource
	private CallRecordDao callRecordDao  ;
	@Resource
	private ContactsDao contactsDao  ;
	
	/**
	 * #我的联系人
	 * /houtai/contacts/my/manage
	 */
	@RequestMapping("/my/manage")
	public ModelAndView manage() throws Exception {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("/pc/contacts/my_manage");
		return mav;
	}
	
	
	/**
	 *   /houtai/contacts/add?callRecordId=12
	 *   state =1 呼出记录添加号码   使用phone2        =2呼入记录添加号码   使用phone1 
	 */
	@RequestMapping("/add")
	public ModelAndView add(@RequestParam(value = "callRecordId", required = false) Integer callRecordId
			,@RequestParam(value = "state", required = false) Integer state) throws Exception {
		ModelAndView mav = new ModelAndView();
		CallRecord callRecord =    callRecordDao.findId(callRecordId);
		if(state==1) {
			mav.addObject("phone", callRecord.getPhone2());
		}else {
			mav.addObject("phone", callRecord.getPhone1());
		}
		
		mav.addObject("callRecord", callRecord);
		mav.addObject("save_url", "/admin/contacts/add");
		
		mav.setViewName("/pc/contacts/add");
		return mav;
	}
	
	
	/**
	 * /houtai/contacts/edit?id=1
	 */
	@RequestMapping("/edit")
	public ModelAndView edit(@RequestParam(value = "id", required = false) Integer id) throws Exception {
		ModelAndView mav = new ModelAndView();
		Contacts contacts = contactsDao.findId(id);
		mav.addObject("contacts", contacts);
		mav.addObject("btn_text", "修改");
		mav.addObject("save_url", "/admin/contacts/update?id=" + id);
		mav.setViewName("/admin/page/contacts/edit");
		return mav;
	}
	
	
}
