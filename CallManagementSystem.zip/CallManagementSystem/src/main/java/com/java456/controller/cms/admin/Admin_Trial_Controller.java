package com.java456.controller.cms.admin;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.java456.dao.cms.TrialDao;
import com.java456.entity.base.Role;
import com.java456.entity.cms.Client;
import com.java456.entity.cms.Contacts;
import com.java456.entity.cms.Trial;
import com.java456.service.cms.CallRecordService;
import com.java456.service.cms.TrialService;
import com.java456.util.StringUtil;

import net.sf.json.JSONObject;

@Controller
@RequestMapping("/admin/trial")
public class Admin_Trial_Controller {

	@Resource
	private  TrialDao trialDao;
	@Resource
	private  TrialService  trialService;
	
	/**
	 * /admin/trial/add
	 */
	@ResponseBody
	@RequestMapping("/add")
	public JSONObject add(@Valid Trial trial  ,BindingResult bindingResult, HttpSession session) throws Exception {
		JSONObject result = new JSONObject();
		
		if(bindingResult.hasErrors()){
			result.put("success", false);
			result.put("msg", bindingResult.getFieldError().getDefaultMessage());
			return result;
		}else{
			Client client =(Client) session.getAttribute("client");
			trial.setApplicant(client);
			trial.setState(0);
			
			trial.setCreateDateTime(new Date());
			trialDao.save(trial);
			result.put("success", true);
			result.put("msg", "Complainted successfully");
			return result;
		}
	}
	
	/**
	 * /admin/trial/update
	 */
	@ResponseBody
	@RequestMapping("/update")
	public JSONObject update(@Valid Trial trial  ,BindingResult bindingResult)throws Exception {
		JSONObject result = new JSONObject();
		if(bindingResult.hasErrors()){  
			result.put("success", false);
			result.put("msg", bindingResult.getFieldError().getDefaultMessage());
			return result;
		}else{
			trialService.update(trial);
			result.put("success", true);
			result.put("msg", "modified successfully");
			return result;
		}
	} 
	
	
	/**
	 * /admin/trial/list    applicantId=1
	 * @param page    默认1
	 * @param limit   数据多少  
	 */
	@ResponseBody
	@RequestMapping("/list")
	public Map<String, Object> list(@RequestParam(value = "page", required = false) Integer page,
			@RequestParam(value = "limit", required = false) Integer limit,
			@RequestParam(value = "applicantId", required = false) Integer applicantId,
			@RequestParam(value = "q", required = false) String q,
			HttpServletResponse response,
			HttpServletRequest request) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		
		if(applicantId!=null) {
			Client applicant = new Client();
			applicant.setId(applicantId);
			map.put("applicant", applicant);
		}
		
		if(StringUtil.isNotEmpty(q))
			map.put("q", q);
		
		List<Trial> list = trialService.list(map, page-1, limit);
		Long total = trialService.getTotal(map);
		map.clear();
		map.put("data", list);
		map.put("count", total);
		map.put("code", 0);
		map.put("msg", "");
		return map;
	}
	
	
	
	
	
}
