package com.java456.controller.cms.houtai;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.java456.dao.cms.NoticeDao;
import com.java456.dao.cms.TrialDao;
import com.java456.entity.cms.CallRecord;
import com.java456.entity.cms.Notice;
import com.java456.entity.cms.Trial;

@Controller
@RequestMapping("/houtai/notice")
public class HouTai_Notice_Controller {
	
	@Resource
	private NoticeDao noticeDao  ;
	
	/**
	 * # 申诉管理
	 * /houtai/notice/manage
	 */
	@RequestMapping("/manage")
	public ModelAndView manage() throws Exception {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("/admin/page/notice/notice_manage");
		return mav;
	}
	
	/**
	 * /houtai/notice/add
	 */
	@RequestMapping("/add")
	public ModelAndView add() throws Exception {
		ModelAndView mav = new ModelAndView();
		
		mav.addObject("btn_text", "添加");
		mav.addObject("save_url", "/admin/notice/add");
		mav.setViewName("/admin/page/notice/add_update");
		return mav;
	}
	
	
	/**
	 * /houtai/notice/edit
	 */
	@RequestMapping("/edit")
	public ModelAndView edit(@RequestParam(value = "id", required = false) Integer id) throws Exception {
		ModelAndView mav = new ModelAndView();
		Notice notice = noticeDao.findId(id);
		mav.addObject("notice", notice);
		mav.addObject("btn_text", "修改");
		mav.addObject("save_url", "/admin/notice/update?id=" + id);
		mav.setViewName("/admin/page/notice/add_update");
		return mav;
	}
	
	
}
