package com.java456.controller.cms.admin;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.java456.dao.cms.ContactsDao;
import com.java456.dao.cms.TrialDao;
import com.java456.entity.base.Role;
import com.java456.entity.cms.CallRecord;
import com.java456.entity.cms.Client;
import com.java456.entity.cms.Contacts;
import com.java456.entity.cms.Trial;
import com.java456.service.cms.ContactsService;
import com.java456.util.StringUtil;

import net.sf.json.JSONObject;

@Controller
@RequestMapping("/admin/contacts")
public class Admin_Contacts_Controller {
	
	@Resource
	private  ContactsDao contactsDao;
	@Resource
	private  ContactsService contactsService;
	
	/**
	 * /admin/contacts/add
	 */
	@ResponseBody
	@RequestMapping("/add")
	public JSONObject add(@Valid Contacts contacts    ,BindingResult bindingResult, HttpSession session) throws Exception {
		JSONObject result = new JSONObject();
		
		if(bindingResult.hasErrors()){
			result.put("success", false);
			result.put("msg", bindingResult.getFieldError().getDefaultMessage());
			return result;
		}else{
			Client client =(Client) session.getAttribute("client");
			contacts.setCreateClient(client);
			contacts.setCreateDateTime(new Date());
			contactsDao.save(contacts);
			result.put("success", true);
			result.put("msg", "added successfully");
			return result;
		}
	}
	
	/**
	 * /admin/contacts/update
	 */
	@ResponseBody
	@RequestMapping("/update")
	public JSONObject update(@Valid Contacts contacts,BindingResult bindingResult)throws Exception {
		JSONObject result = new JSONObject();
		
		if(bindingResult.hasErrors()){  
			result.put("success", false);
			result.put("msg", bindingResult.getFieldError().getDefaultMessage());
			return result;
		}else{
			contactsService.update(contacts);
			result.put("success", true);
			result.put("msg", "modified successfully");
			return result;
		}
	} 
	
	
	/**
	 * /admin/contacts/list    layuitable
	 * @param page    默认1
	 * @param limit   数据多少  
	 */
	@ResponseBody
	@RequestMapping("/list")
	public Map<String, Object> list(@RequestParam(value = "page", required = false) Integer page,
			@RequestParam(value = "limit", required = false) Integer limit,
			@RequestParam(value = "createClientId", required = false) Integer createClientId,
			@RequestParam(value = "q", required = false) String q,
			HttpServletResponse response,
			HttpServletRequest request) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		
		if(createClientId!=null) {
			Client createClient = new Client();
			createClient.setId(createClientId);
			map.put("createClient", createClient);
		}
		
		
		if(StringUtil.isNotEmpty(q))
			map.put("q", q);
		
		List<Contacts> list = contactsService.list(map, page-1, limit);
		Long total = contactsService.getTotal(map);
		map.clear();
		map.put("data", list);
		map.put("count", total);
		map.put("code", 0);
		map.put("msg", "");
		return map;
	}
	
	
	/**
	 * /admin/role/delete
	 */
	@ResponseBody
	@RequestMapping("/delete")
	public JSONObject delete(@RequestParam(value = "ids", required = false) String ids, HttpServletResponse response)
			throws Exception {
		String[] idsStr = ids.split(",");
		JSONObject result = new JSONObject();
		
		for (int i = 0; i < idsStr.length; i++) {
			try {
				contactsDao.deleteById(Integer.parseInt(idsStr[i]));
			} catch (Exception e) {
				result.put("success", false);
				return result;
			}
		}
		
		result.put("success", true);
		return result;
	}
	
	
}
