package com.java456.controller.cms.houtai;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.java456.dao.cms.ClientDao;
import com.java456.entity.cms.Client;
import com.java456.entity.cms.Trial;
import com.java456.service.cms.CallRecordService;

@Controller
@RequestMapping("/houtai/client")
public class HouTai_Client_Controller {
	
	@Resource
	private ClientDao clientDao  ;
	
	/**
	 * #呼出记录的页面
	 * /houtai/client/manage
	 */
	@RequestMapping("/manage")
	public ModelAndView manage() throws Exception {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("/admin/page/client/manage");
		return mav;
	}
	
	/**
	 * /houtai/client/edit?id=1
	 */
	@RequestMapping("/edit")
	public ModelAndView edit(@RequestParam(value = "id", required = false) Integer id) throws Exception {
		ModelAndView mav = new ModelAndView();
		Client client = clientDao.findId(id);
		mav.addObject("client", client);
		mav.addObject("btn_text", "修改");
		mav.addObject("save_url", "/admin/client/update?id=" + id);
		mav.setViewName("/admin/page/client/edit");
		return mav;
	}
	
	
}
