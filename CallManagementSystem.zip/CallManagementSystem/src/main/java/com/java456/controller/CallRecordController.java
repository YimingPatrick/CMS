package com.java456.controller;

import java.util.Date;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.java456.dao.cms.CallRecordDao;
import com.java456.dao.cms.ClientDao;
import com.java456.entity.cms.CallRecord;
import com.java456.entity.cms.Client;

import net.sf.json.JSONObject;

@Controller
@RequestMapping("/call/record")
public class CallRecordController {
	
	@Resource
	private CallRecordDao callRecordDao;
	@Resource
	private ClientDao clientDao;
	
	
	/**
	 *   /call/record/add
	 */
	@ResponseBody
	@RequestMapping("/add")
	public JSONObject add(String phone,HttpSession session) throws Exception {
		JSONObject result = new JSONObject();
		
		Client client = (Client) session.getAttribute("client");
		Client tempClient = clientDao.findByPhone(phone);
		
		CallRecord cr = new CallRecord();
		cr.setPhone1(client.getPhone());
		cr.setPhone2(phone);
		
		cr.setInitiator(client);
		cr.setCreateDateTime(new Date());
		cr.setReceiver(tempClient);
		callRecordDao.save(cr);
		
		result.put("msg", " Successfully");
		result.put("success", true);
		return result;
	}
	
	
}
