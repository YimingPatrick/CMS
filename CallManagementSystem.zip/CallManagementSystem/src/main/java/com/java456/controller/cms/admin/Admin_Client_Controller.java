package com.java456.controller.cms.admin;


import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import com.java456.dao.cms.ClientDao;
import com.java456.entity.cms.Client;
import com.java456.service.cms.ClientService;
import com.java456.util.StringUtil;
import net.sf.json.JSONObject;


@Controller
@RequestMapping("/admin/client")
public class Admin_Client_Controller {
	
	
	@Resource
	private  ClientDao clientDao;
	@Resource
	private ClientService  clientService;
	
	
	/**
	 * /admin/client/update
	 */
	@ResponseBody
	@RequestMapping("/update")
	public JSONObject update(@Valid Client client  ,BindingResult bindingResult)throws Exception {
		JSONObject result = new JSONObject();
		if(bindingResult.hasErrors()){  
			result.put("success", false);
			result.put("msg", bindingResult.getFieldError().getDefaultMessage());
			return result;
		}else{
			clientService.update(client);
			result.put("success", true);
			result.put("msg", "modified successfully");
			return result;
		}
	} 
	
	
	/**
	 * /admin/client/list     
	 * @param page    默认1
	 * @param limit   数据多少  
	 */
	@ResponseBody
	@RequestMapping("/list")
	public Map<String, Object> list(@RequestParam(value = "page", required = false) Integer page,
			@RequestParam(value = "limit", required = false) Integer limit,
			@RequestParam(value = "q", required = false) String q,
			HttpServletResponse response,
			HttpServletRequest request) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		if(StringUtil.isNotEmpty(q))
			map.put("q", q);
		
		List<Client> list = clientService.list(map, page-1, limit);
		Long total = clientService.getTotal(map);
		map.clear();
		map.put("data", list);
		map.put("count", total);
		map.put("code", 0);
		map.put("msg", "");
		return map;
	}
	
	
	/**
	 * /admin/client/updateAll?state=1
	 */
	@ResponseBody
	@RequestMapping("/updateAll")
	public JSONObject updateAll(@RequestParam(value = "state", required = false) Integer state)throws Exception {
		JSONObject result = new JSONObject();
		Map<String, Object> map = new HashMap<String, Object>();
		List<Client> list = clientService.list(map , 0, 200);
		for(Client client : list) {
			if(client.getState()!=2) {
				client.setState(state);
				clientService.update(client);
			}
		}
		result.put("success", true);
		result.put("msg", "modified successfully");
		return result;
	}
	
	
}
