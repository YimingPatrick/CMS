package com.java456.controller.cms.admin;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.java456.dao.cms.CallRecordDao;
import com.java456.entity.cms.CallRecord;
import com.java456.entity.cms.Client;
import com.java456.service.cms.CallRecordService;
import com.java456.util.StringUtil;



@Controller
@RequestMapping("/admin/call/record")
public class Admin_CallRecord_Controller {
	
	@Resource
	private  CallRecordService callRecordService;
	
	
	/**
	 * /admin/call/record/list  layuitable
	 * @param page    默认1
	 * @param limit   数据多少  
	 */
	@ResponseBody
	@RequestMapping("/list")
	public Map<String, Object> list(@RequestParam(value = "page", required = false) Integer page,
			@RequestParam(value = "limit", required = false) Integer limit,
			@RequestParam(value = "initiatorId", required = false) Integer initiatorId,
			@RequestParam(value = "receiverId", required = false) Integer receiverId,
			@RequestParam(value = "q", required = false) String q,
			HttpServletResponse response,
			HttpServletRequest request) throws Exception {
		Map<String, Object> map = new HashMap<String, Object>();
		
		
		if(initiatorId!=null) {
			Client initiator = new Client();
			initiator.setId(initiatorId);
			map.put("initiator", initiator);
		}
		if(receiverId!=null) {
			Client receiver = new Client();
			receiver.setId(receiverId);
			map.put("receiver", receiver);
		}
		
		
		if(StringUtil.isNotEmpty(q))
			map.put("q", q);
		
		List<CallRecord> list = callRecordService.list(map, page-1, limit);
		Long total = callRecordService.getTotal(map);
		map.clear();
		map.put("data", list);
		map.put("count", total);
		map.put("code", 0);
		map.put("msg", "");
		return map;
	}
	
	
	
	
	
}
