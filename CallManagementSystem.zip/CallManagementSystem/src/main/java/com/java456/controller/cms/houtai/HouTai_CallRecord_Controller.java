package com.java456.controller.cms.houtai;



import java.util.List;
import java.util.Map;
import javax.annotation.Resource;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.java456.dao.base.UserDao;
import com.java456.entity.base.Role;
import com.java456.entity.base.User;
import com.java456.service.cms.CallRecordService;


@Controller
@RequestMapping("/houtai/call/record")
public class HouTai_CallRecord_Controller {
	
	@Resource
	private CallRecordService callRecordService  ;
	
	/**
	 * #呼出记录的页面
	 * /houtai/call/record/manage1
	 */
	@RequestMapping("/manage1")
	public ModelAndView manage() throws Exception {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("/pc/call_record/initiator_manage");
		return mav;
	}
	
	
	/**
	 * #呼入记录的页面
	 * /houtai/call/record/manage2
	 */
	@RequestMapping("/manage2")
	public ModelAndView manage2() throws Exception {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("/pc/call_record/receiver_manage");
		return mav;
	}
	
}
